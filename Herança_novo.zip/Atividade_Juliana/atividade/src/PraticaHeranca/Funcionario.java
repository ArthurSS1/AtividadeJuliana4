package PraticaHeranca;

import java.util.ArrayList;
import java.util.List;

public class Funcionario {
    private List<Funcionario> funcionarios;

    public Funcionario() {
        funcionarios = new ArrayList<>();
    }

    public void adicionarFuncionario(Funcionario funcionario) {
        funcionarios.add(funcionario);
    }

    public Funcionario buscarFuncionarioPorNome(String nome) {
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getNome().equalsIgnoreCase(nome)) {
                return funcionario;
            }
        }
        return null;
    }

    public void atualizarSalario(Funcionario funcionario, double novoSalario) {
        funcionario.setNumber(novoSalario);
    }

    public void excluirFuncionario(Funcionario funcionario) {
        funcionarios.remove(funcionario);
    }

    public List<Funcionario> listarFuncionarios() {
        return funcionarios;
    }

    public static void main(String[] args) {
        Funcionario gerenciador = new Funcionario();

        // Adicionar funcionários
        Funcionario funcionario1 = new Funcionario();
        funcionario1.setNome("João");
        funcionario1.setNumber(3000);
        gerenciador.adicionarFuncionario(funcionario1);

        Funcionario funcionario2 = new Funcionario();
        funcionario2.setNome("Maria");
        funcionario2.setNumber(3500);
        gerenciador.adicionarFuncionario(funcionario2);

        // Consultar funcionário por nome
        Funcionario consulta = gerenciador.buscarFuncionarioPorNome("João");
        if (consulta != null) {
            System.out.println("Funcionário encontrado: " + consulta.getNome() + ", Salário: " + consulta.getNumber());
        } else {
            System.out.println("Funcionário não encontrado.");
        }

        // Atualizar salário
        if (consulta != null) {
            gerenciador.atualizarSalario(consulta, 3200);
            System.out.println("Salário atualizado: " + consulta.getNumber());
        }

        // Listar todos os funcionários
        List<Funcionario> funcionarios = gerenciador.listarFuncionarios();
        System.out.println("Lista de funcionários:");
        for (Funcionario funcionario : funcionarios) {
            System.out.println("Nome: " + funcionario.getNome() + ", Salário: " + funcionario.getNumber());
        }

        // Excluir funcionário
        if (consulta != null) {
            gerenciador.excluirFuncionario(consulta);
            System.out.println("Funcionário excluído.");
        }
    }
}
