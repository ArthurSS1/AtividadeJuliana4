package PraticaHeranca;

public class Main {

	public static void main(String[] args) {
		
		Secretario s1 = new Secretario();
		s1.setNome("Lucas");
		System.out.println(s1.getNome());

	}

}
