
public class Exemplo_Funcionario {

	 public static void main(String[] args) {
	        GerenciadorFuncionarios gerenciador = new GerenciadorFuncionarios();

	        Funcionario funcionario1 = new Funcionario();
	        funcionario1.setNome("João");
	        funcionario1.setNumber(3000);
	        gerenciador.adicionarFuncionario(funcionario1);

	        Funcionario funcionario2 = new Funcionario();
	        funcionario2.setNome("Maria");
	        funcionario2.setNumber(3500);
	        gerenciador.adicionarFuncionario(funcionario2);

	        Funcionario consulta = gerenciador.buscarFuncionarioPorNome("João");
	        if (consulta != null) {
	            System.out.println("Funcionário encontrado: " + consulta.getNome() + ", Salário: " + consulta.getNumber());
	        } else {
	            System.out.println("Funcionário não encontrado.");
	        }

	        if (consulta != null) {
	            gerenciador.atualizarSalario(consulta, 3200);
	            System.out.println("Salário atualizado: " + consulta.getNumber());
	        }

	        List<Funcionario> funcionarios = gerenciador.listarFuncionarios();
	        System.out.println("Lista de funcionários:");
	        for (Funcionario funcionario : funcionarios) {
	            System.out.println("Nome: " + funcionario.getNome() + ", Salário: " + funcionario.getNumber());
	        }

	        if (consulta != null) {
	            gerenciador.excluirFuncionario(consulta);
	            System.out.println("Funcionário excluído.");
	        }
	    }
	}
