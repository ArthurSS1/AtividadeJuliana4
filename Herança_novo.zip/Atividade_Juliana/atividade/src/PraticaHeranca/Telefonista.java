package PraticaHeranca;

public class Telefonista extends Funcionario {
	
	int codigoEstacaoTrabalho;

	
	public int getCodigoEstacaoTrabalho() {
		return codigoEstacaoTrabalho;
	}

	public void setCodigoEstacaoTrabalho(int cet) {
		codigoEstacaoTrabalho = cet;
	} 
	
}
